/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MazeGame;

/**
 *
 * @author liguo
 */
public class Peanut extends Nut{

    public Peanut ()
    {
    this.NUTRITION_POINTS = 10;//constant
    this.symbol = "P";
    this.name = "Peanut";
    create();
    }
}
