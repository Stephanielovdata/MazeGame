/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MazeGame;

/**
 *
 * @author liguo
 */
public class PoisonousCashew extends Nut {
    public PoisonousCashew ()
    {
    this.NUTRITION_POINTS = -15;
    this.symbol = "C";
    this.name = "PoisonousCashew";
    create();
    }
    
}
